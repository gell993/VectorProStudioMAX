package com.vectorpro.studio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas as ACanvas
import android.graphics.Paint as APaint
import android.graphics.Path as APath
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private enum class Tool { SELECT, PEN, LINE, RECT, ELLIPSE, BEZIER, TEXT }
private enum class Kind { FREEHAND, LINE, RECT, ELLIPSE, BEZIER, TEXT }

private data class Obj(
    val id: Long,
    val kind: Kind,
    val points: List<Offset>,
    val color: Color,
    val width: Float,
    val text: String = "",
    val fontSize: Float = 42f,
    val fill: Boolean = false,
    val visible: Boolean = true,
    val locked: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaxEditor() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MaxEditor() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val objects = remember { mutableStateListOf<Obj>() }
    val undoStack = remember { mutableStateListOf<List<Obj>>() }
    var tool by remember { mutableStateOf(Tool.PEN) }
    var color by remember { mutableStateOf(Color(0xFF6C5CE7)) }
    var width by remember { mutableFloatStateOf(6f) }
    var fill by remember { mutableStateOf(false) }
    var active by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var selected by remember { mutableStateOf<Long?>(null) }
    var showLayers by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("VectorPro MAX") }
    var textSize by remember { mutableFloatStateOf(48f) }
    var projectName by remember { mutableStateOf("Proyek Baru") }
    var showProject by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showBezierHelp by remember { mutableStateOf(false) }
    var canvasSize by remember { mutableStateOf(Size(1080f, 1080f)) }

    val palette = listOf(
        Color(0xFF6C5CE7), Color(0xFF111827), Color(0xFFE74C3C),
        Color(0xFFFFB020), Color(0xFF16A085), Color(0xFF2980B9),
        Color(0xFFE84393), Color(0xFF00B894), Color.White, Color(0xFF795548)
    )

    fun saveHistory() {
        undoStack.add(objects.toList())
        if (undoStack.size > 50) undoStack.removeAt(0)
    }
    fun undo() {
        if (undoStack.isNotEmpty()) {
            val old = undoStack.removeAt(undoStack.lastIndex)
            objects.clear(); objects.addAll(old); selected = null
        }
    }
    fun addObject(obj: Obj) {
        saveHistory(); objects.add(obj); selected = obj.id
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8B7CFF), surface = Color(0xFF1B2638))) {
        Scaffold(
            containerColor = Color(0xFF101827),
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("VectorPro Studio MAX", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(projectName, fontSize = 11.sp, color = Color(0xFF9BA9BD))
                        }
                    },
                    actions = {
                        IconButton(onClick = { showProject = true }) { Icon(Icons.Default.FolderOpen, "Project") }
                        IconButton(onClick = { undo() }) { Icon(Icons.Default.Undo, "Undo") }
                        IconButton(onClick = { showLayers = true }) { Icon(Icons.Default.Layers, "Layers") }
                        IconButton(onClick = { showExport = true }) { Icon(Icons.Default.FileDownload, "Export") }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF101827), titleContentColor = Color.White, actionIconContentColor = Color.White)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(Color(0xFF1B2638)).navigationBarsPadding().padding(horizontal = 10.dp, vertical = 7.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Tool.entries.forEach { t ->
                            val label = when(t) {
                                Tool.SELECT -> "Pilih"; Tool.PEN -> "Pensil"; Tool.LINE -> "Garis"
                                Tool.RECT -> "Kotak"; Tool.ELLIPSE -> "Oval"; Tool.BEZIER -> "Bezier"; Tool.TEXT -> "Teks"
                            }
                            val icon = when(t) {
                                Tool.SELECT -> Icons.Default.NearMe; Tool.PEN -> Icons.Default.Edit
                                Tool.LINE -> Icons.Default.ShowChart; Tool.RECT -> Icons.Default.Rectangle
                                Tool.ELLIPSE -> Icons.Default.Circle; Tool.BEZIER -> Icons.Default.Gesture
                                Tool.TEXT -> Icons.Default.TextFields
                            }
                            FilledTonalButton(
                                onClick = {
                                    if (tool == Tool.BEZIER && active.size >= 4) finishBezier(active, ::addObject)
                                    tool = t; active = emptyList()
                                    if (t == Tool.BEZIER) showBezierHelp = true
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (tool == t) Color(0xFF6C5CE7) else Color(0xFF2A3850),
                                    contentColor = Color.White
                                )
                            ) { Icon(icon, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text(label, fontSize = 11.sp) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Stroke", color = Color.White, fontSize = 11.sp)
                        Slider(value = width, onValueChange = { width = it }, valueRange = 1f..30f, modifier = Modifier.weight(1f))
                        Text("${width.toInt()} px", color = Color.White, fontSize = 10.sp)
                        Spacer(Modifier.width(5.dp))
                        FilterChip(selected = fill, onClick = { fill = !fill }, label = { Text("Isi", fontSize = 10.sp) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("Warna", color = Color(0xFF9BA9BD), fontSize = 10.sp)
                        palette.forEach { c ->
                            Box(Modifier.size(24.dp).background(c, CircleShape)
                                .then(if (color == c) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                                .clickable { color = c })
                        }
                    }
                    if (tool == Tool.BEZIER) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Ketuk 4 titik: awal, kontrol 1, kontrol 2, akhir", color = Color(0xFFCFD7E5), fontSize = 10.sp)
                            TextButton(onClick = {
                                if (active.size >= 4) finishBezier(active, ::addObject)
                                active = emptyList()
                            }) { Text("Selesai", color = Color.White) }
                        }
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("KANVAS • RGB", color = Color(0xFF9BA9BD), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${objects.size} objek  |  ${tool.name}", color = Color(0xFF9BA9BD), fontSize = 10.sp)
                }
                Spacer(Modifier.height(8.dp))
                Canvas(
                    Modifier.fillMaxSize().background(Color.White, RoundedCornerShape(8.dp))
                        .pointerInput(tool, objects.size, selected, color, width, fill) {
                            detectTapGestures { p ->
                                when(tool) {
                                    Tool.SELECT -> selected = objects.lastOrNull { it.visible && !it.locked && hit(it,p) }?.id
                                    Tool.TEXT -> { active = listOf(p); showText = true }
                                    Tool.BEZIER -> {
                                        active = active + p
                                        if (active.size == 4) {
                                            finishBezier(active, ::addObject)
                                            active = emptyList()
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                        .pointerInput(tool, selected, objects.size, color, width, fill) {
                            detectDragGestures(
                                onDragStart = { p ->
                                    if (tool == Tool.SELECT) {
                                        val found = objects.lastOrNull { it.visible && !it.locked && hit(it,p) }
                                        selected = found?.id
                                        active = if (found != null) listOf(p) else emptyList()
                                    } else active = listOf(p)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    if (tool == Tool.SELECT && selected != null && active.isNotEmpty()) {
                                        val dx = change.position.x - active.last().x
                                        val dy = change.position.y - active.last().y
                                        val idx = objects.indexOfFirst { it.id == selected }
                                        if (idx >= 0) {
                                            val o = objects[idx]
                                            if (!o.locked) objects[idx] = o.copy(points = o.points.map { Offset(it.x+dx,it.y+dy) })
                                        }
                                        active = active + change.position
                                    } else if (tool != Tool.BEZIER) active = active + change.position
                                },
                                onDragEnd = {
                                    if (tool == Tool.SELECT) {
                                        if (active.size > 1) saveHistory()
                                    } else if (active.isNotEmpty() && tool != Tool.TEXT) {
                                        val kind = when(tool) {
                                            Tool.PEN -> Kind.FREEHAND; Tool.LINE -> Kind.LINE
                                            Tool.RECT -> Kind.RECT; Tool.ELLIPSE -> Kind.ELLIPSE
                                            else -> Kind.FREEHAND
                                        }
                                        addObject(Obj(System.nanoTime(),kind,active,color,width,fill=fill))
                                    }
                                    active = emptyList()
                                }
                            )
                        }
                ) {
                    canvasSize = size
                    objects.filter { it.visible }.forEach { drawObj(it, selected == it.id) }
                    if (active.isNotEmpty() && tool != Tool.SELECT && tool != Tool.TEXT && tool != Tool.BEZIER) {
                        val k = when(tool) {
                            Tool.PEN -> Kind.FREEHAND; Tool.LINE -> Kind.LINE
                            Tool.RECT -> Kind.RECT; Tool.ELLIPSE -> Kind.ELLIPSE
                            else -> Kind.FREEHAND
                        }
                        drawObj(Obj(-1,k,active,color.copy(alpha=.7f),width,fill=fill))
                    }
                    if (tool == Tool.BEZIER && active.isNotEmpty()) {
                        active.forEach { drawCircle(Color(0xFF00AEEF), 6f, it) }
                        if (active.size >= 2) drawLine(Color.Gray,active[0],active[1],2f)
                        if (active.size >= 3) drawLine(Color.Gray,active[2],active[3],2f)
                    }
                }
            }
        }

        if (showText) AlertDialog(
            onDismissRequest = { showText = false },
            title = { Text("Text Editor") },
            text = {
                Column {
                    OutlinedTextField(value=text,onValueChange={text=it},label={Text("Tulisan")})
                    Text("Ukuran: ${textSize.toInt()}sp")
                    Slider(value=textSize,onValueChange={textSize=it},valueRange=14f..120f)
                }
            },
            confirmButton = {
                TextButton(onClick={
                    addObject(Obj(System.nanoTime(),Kind.TEXT,active.ifEmpty { listOf(Offset(50f,80f)) },color,1f,text,textSize))
                    active=emptyList(); showText=false
                }) { Text("Tambah") }
            },
            dismissButton = { TextButton(onClick={showText=false}) { Text("Batal") } }
        )

        if (showLayers) AlertDialog(
            onDismissRequest={showLayers=false},
            title={Text("Layer & Objek")},
            text={
                LazyColumn(Modifier.heightIn(max=430.dp)) {
                    itemsIndexed(objects.toList().asReversed()) { reverse, obj ->
                        val index=objects.lastIndex-reverse
                        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(12.dp).background(obj.color,CircleShape))
                            Column(Modifier.weight(1f).padding(start=8.dp)) {
                                Text("${obj.kind} ${index+1}",fontSize=12.sp)
                                Text(if(obj.locked) "Terkunci" else "Dapat diedit",fontSize=10.sp,color=Color.Gray)
                            }
                            IconButton(onClick={objects[index]=obj.copy(visible=!obj.visible)}) {
                                Icon(if(obj.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,"Visible")
                            }
                            IconButton(onClick={objects[index]=obj.copy(locked=!obj.locked)}) {
                                Icon(if(obj.locked) Icons.Default.Lock else Icons.Default.LockOpen,"Lock")
                            }
                            IconButton(onClick={saveHistory();objects.removeAt(index)}) {
                                Icon(Icons.Default.Delete,"Delete",tint=Color.Red)
                            }
                        }
                        HorizontalDivider()
                    }
                }
            },
            confirmButton={TextButton(onClick={ { showLayers=false } }) { Text("Tutup") }}
        )

        if (showProject) AlertDialog(
            onDismissRequest={showProject=false},
            title={Text("Pengaturan proyek")},
            text={OutlinedTextField(value=projectName,onValueChange={projectName=it},label={Text("Nama proyek")})},
            confirmButton={TextButton(onClick={ { showProject=false } }) { Text("Simpan") }}
        )

        if (showExport) AlertDialog(
            onDismissRequest={showExport=false},
            title={Text("Ekspor karya")},
            text={Text("Pilih format ekspor. PNG untuk gambar siap pakai, SVG untuk vektor yang dapat diedit di aplikasi kompatibel.")},
            confirmButton={TextButton(onClick={exportPng(context,objects.toList(),canvasSize);showExport=false}) { Text("PNG") }},
            dismissButton={
                Row {
                    TextButton(onClick={exportSvg(context,objects.toList(),canvasSize);showExport=false}) { Text("SVG") }
                    TextButton(onClick={ { showExport=false } }) { Text("Tutup") }
                }
            }
        )

        if (showBezierHelp) AlertDialog(
            onDismissRequest={showBezierHelp=false},
            title={Text("Alat Bézier")},
            text={Text("Ketuk kanvas empat kali: titik awal, kontrol pertama, kontrol kedua, dan titik akhir. Hasilnya adalah kurva Bézier kubik.")},
            confirmButton={TextButton(onClick={ { showBezierHelp=false } }) { Text("Mengerti") }}
        )
    }
}

private fun finishBezier(points: List<Offset>, add: (Obj)->Unit) {
    if(points.size < 4) return
    add(Obj(System.nanoTime(),Kind.BEZIER,points.take(4),Color(0xFF6C5CE7),5f))
}
private fun hit(o: Obj,p: Offset): Boolean {
    if(o.points.isEmpty()) return false
    val xs=o.points.map{it.x}; val ys=o.points.map{it.y}
    return p.x in (xs.min()-28)..(xs.max()+28) && p.y in (ys.min()-28)..(ys.max()+28)
}
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawObj(o: Obj, selected: Boolean=false) {
    if(o.points.isEmpty()) return
    val a=o.points.first(); val b=o.points.last()
    val style=if(o.fill && (o.kind==Kind.RECT || o.kind==Kind.ELLIPSE)) androidx.compose.ui.graphics.drawscope.Fill else Stroke(o.width,cap=StrokeCap.Round,join=StrokeJoin.Round)
    when(o.kind) {
        Kind.FREEHAND -> {
            val p=Path().apply { moveTo(a.x,a.y);o.points.drop(1).forEach{lineTo(it.x,it.y)} }
            drawPath(p,o.color,style=Stroke(o.width,cap=StrokeCap.Round,join=StrokeJoin.Round))
        }
        Kind.LINE -> drawLine(o.color,a,b,o.width,cap=StrokeCap.Round)
        Kind.RECT -> drawRect(o.color,Offset(min(a.x,b.x),min(a.y,b.y)),Size(abs(b.x-a.x),abs(b.y-a.y)),style=style)
        Kind.ELLIPSE -> drawOval(o.color,Offset(min(a.x,b.x),min(a.y,b.y)),Size(abs(b.x-a.x),abs(b.y-a.y)),style=style)
        Kind.BEZIER -> {
            val p=Path().apply { moveTo(o.points[0].x,o.points[0].y);cubicTo(o.points[1].x,o.points[1].y,o.points[2].x,o.points[2].y,o.points[3].x,o.points[3].y) }
            drawPath(p,o.color,style=Stroke(o.width,cap=StrokeCap.Round))
        }
        Kind.TEXT -> {
            val paint=APaint().apply { color=o.color.toArgb();textSize=o.fontSize;typeface=Typeface.create("sans-serif",Typeface.BOLD);isAntiAlias=true }
            drawContext.canvas.nativeCanvas.drawText(o.text,a.x,a.y,paint)
        }
    }
    if(selected) {
        val xs=o.points.map{it.x};val ys=o.points.map{it.y}
        drawRect(Color(0xFF00AEEF),Offset(xs.min()-8,ys.min()-8),Size(xs.max()-xs.min()+16,ys.max()-ys.min()+16),style=Stroke(2f))
    }
}

private fun exportPng(ctx: android.content.Context, list: List<Obj>, size: Size) {
    val w=size.width.toInt().coerceAtLeast(720);val h=size.height.toInt().coerceAtLeast(720)
    val bitmap=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);val c=ACanvas(bitmap);c.drawColor(android.graphics.Color.WHITE)
    list.filter{it.visible}.forEach{drawNative(c,it)}
    val values=ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME,"VectorPro_MAX_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE,"image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/VectorProStudio")
    }
    val uri=ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)
    if(uri!=null) ctx.contentResolver.openOutputStream(uri)?.use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
    bitmap.recycle()
    Toast.makeText(ctx,if(uri!=null)"PNG tersimpan di Pictures/VectorProStudio" else "Ekspor gagal",Toast.LENGTH_LONG).show()
}
private fun drawNative(c: ACanvas,o: Obj) {
    if(o.points.isEmpty()) return
    val p=APaint().apply {
        color=o.color.toArgb();strokeWidth=o.width;style=if(o.fill && (o.kind==Kind.RECT||o.kind==Kind.ELLIPSE)) APaint.Style.FILL else APaint.Style.STROKE
        strokeCap=APaint.Cap.ROUND;strokeJoin=APaint.Join.ROUND;isAntiAlias=true
    }
    val a=o.points.first();val b=o.points.last()
    when(o.kind) {
        Kind.FREEHAND -> { val path=APath().apply{moveTo(a.x,a.y);o.points.drop(1).forEach{lineTo(it.x,it.y)}};c.drawPath(path,p) }
        Kind.LINE -> c.drawLine(a.x,a.y,b.x,b.y,p)
        Kind.RECT -> c.drawRect(min(a.x,b.x),min(a.y,b.y),max(a.x,b.x),max(a.y,b.y),p)
        Kind.ELLIPSE -> c.drawOval(min(a.x,b.x),min(a.y,b.y),max(a.x,b.x),max(a.y,b.y),p)
        Kind.BEZIER -> { val path=APath().apply{moveTo(o.points[0].x,o.points[0].y);cubicTo(o.points[1].x,o.points[1].y,o.points[2].x,o.points[2].y,o.points[3].x,o.points[3].y)};c.drawPath(path,p) }
        Kind.TEXT -> { p.style=APaint.Style.FILL;p.textSize=o.fontSize;p.typeface=Typeface.DEFAULT_BOLD;c.drawText(o.text,a.x,a.y,p) }
    }
}
private fun exportSvg(ctx: android.content.Context,list: List<Obj>,size: Size) {
    val w=size.width.toInt().coerceAtLeast(720);val h=size.height.toInt().coerceAtLeast(720)
    fun hex(c:Color)=String.format("#%02X%02X%02X",(c.red*255).toInt(),(c.green*255).toInt(),(c.blue*255).toInt())
    val body=list.filter{it.visible}.joinToString("\n"){o->
        if(o.points.isEmpty()) "" else {
            val a=o.points.first();val b=o.points.last();val col=hex(o.color);val sw=o.width
            when(o.kind) {
                Kind.LINE -> """<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="$col" stroke-width="$sw"/>"""
                Kind.RECT -> """<rect x="${min(a.x,b.x)}" y="${min(a.y,b.y)}" width="${abs(b.x-a.x)}" height="${abs(b.y-a.y)}" fill="${if(o.fill) col else "none"}" stroke="$col" stroke-width="$sw"/>"""
                Kind.ELLIPSE -> """<ellipse cx="${(a.x+b.x)/2}" cy="${(a.y+b.y)/2}" rx="${abs(b.x-a.x)/2}" ry="${abs(b.y-a.y)/2}" fill="${if(o.fill) col else "none"}" stroke="$col" stroke-width="$sw"/>"""
                Kind.BEZIER -> """<path d="M ${o.points[0].x} ${o.points[0].y} C ${o.points[1].x} ${o.points[1].y}, ${o.points[2].x} ${o.points[2].y}, ${o.points[3].x} ${o.points[3].y}" fill="none" stroke="$col" stroke-width="$sw"/>"""
                Kind.FREEHAND -> """<polyline points="${o.points.joinToString(" "){ "${it.x},${it.y}" }}" fill="none" stroke="$col" stroke-width="$sw"/>"""
                Kind.TEXT -> """<text x="${a.x}" y="${a.y}" font-size="${o.fontSize}" fill="$col">${escapeXml(o.text)}</text>"""
            }
        }
    }
    val svg="""<svg xmlns="http://www.w3.org/2000/svg" width="$w" height="$h" viewBox="0 0 $w $h"><rect width="100%" height="100%" fill="white"/>$body</svg>"""
    val values=ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME,"VectorPro_MAX_${System.currentTimeMillis()}.svg")
        put(MediaStore.Downloads.MIME_TYPE,"image/svg+xml")
        put(MediaStore.Downloads.RELATIVE_PATH,"Download/VectorProStudio")
    }
    val uri=ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
    if(uri!=null) ctx.contentResolver.openOutputStream(uri)?.use{it.write(svg.toByteArray())}
    Toast.makeText(ctx,if(uri!=null)"SVG tersimpan di Download/VectorProStudio" else "Ekspor gagal",Toast.LENGTH_LONG).show()
}
private fun escapeXml(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
