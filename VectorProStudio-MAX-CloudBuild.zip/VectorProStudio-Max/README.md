# VectorPro Studio MAX — Android project

Versi MAX (3.0) adalah proyek sumber Android berbasis Kotlin + Jetpack Compose.

## Fitur
- Kanvas sentuh dengan tool seleksi, freehand, garis, persegi, oval, Bézier kubik, dan teks.
- Seleksi objek dan pemindahan objek dengan drag.
- Warna, ketebalan garis, dan opsi isi bentuk.
- Panel layer: tampil/sembunyi, kunci, hapus.
- Undo hingga 50 langkah.
- Pengaturan nama proyek.
- Ekspor PNG dan SVG.
- Antarmuka gelap profesional.

## Build
1. Ekstrak ZIP.
2. Buka folder `VectorProStudio-Max` di Android Studio.
3. Pasang Android SDK 35 dan tunggu Gradle Sync.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

## Batasan yang perlu diketahui
Ini adalah prototipe MAX yang dapat dikembangkan, belum setara penuh CorelDRAW. Tool Bézier membuat kurva kubik dari empat ketukan (titik awal, dua titik kontrol, titik akhir). Pemindahan objek tersedia, tetapi resize/rotasi dengan handle belum diimplementasikan. Panel layer mengelola objek pada sesi aktif; penyimpanan proyek native, pemuatan proyek, impor foto/SVG, crop, boolean path, PDF, font import, multi-page, dan autosave belum tersedia. Pengujian build akhir perlu dilakukan di Android Studio pada perangkat target.
