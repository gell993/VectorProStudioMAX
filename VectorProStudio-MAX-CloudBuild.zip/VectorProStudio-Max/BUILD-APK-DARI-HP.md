# Membuat APK VectorPro Studio MAX hanya dengan HP Android

Paket ini sudah berisi workflow GitHub Actions untuk membangun APK di server cloud. Anda tidak perlu memasang Android Studio di HP.

## Langkah 1 — Siapkan akun GitHub
1. Buka https://github.com melalui Chrome.
2. Daftar atau masuk.
3. Buat repository baru bernama `VectorProStudioMAX`.
4. Pilih Public atau Private, lalu buat repository.

## Langkah 2 — Unggah source code
1. Ekstrak ZIP ini menggunakan Files / ZArchiver.
2. Di repository GitHub, gunakan menu Add file > Upload files.
3. Unggah isi folder proyek, bukan file ZIP-nya. Pastikan struktur folder tetap sama, termasuk folder tersembunyi `.github/workflows`.
4. Commit perubahan ke branch `main`.

Catatan: browser HP kadang tidak mudah mengunggah folder dan folder tersembunyi. Jika menu Upload files tidak bisa memilih folder, gunakan GitHub versi desktop di Chrome (menu ⋮ > Situs desktop), atau buat file/folder melalui Add file > Create new file dengan path yang sama.

## Langkah 3 — Jalankan build cloud
1. Buka tab Actions pada repository.
2. Pilih workflow `Build VectorPro Studio MAX APK`.
3. Tekan Run workflow > Run workflow.
4. Tunggu sampai proses selesai dengan status hijau.

## Langkah 4 — Unduh APK
1. Buka hasil workflow yang selesai.
2. Gulir ke bagian Artifacts.
3. Unduh `VectorPro-Studio-MAX-APK`.
4. Ekstrak ZIP artifact, lalu ketuk file APK.
5. Jika Android meminta izin, izinkan Chrome / Files memasang aplikasi dari sumber tersebut.

## Catatan penting
- Build menghasilkan debug APK untuk uji coba pribadi, bukan release APK siap Play Store.
- Debug APK ditandatangani dengan debug key otomatis; rilis Play Store membutuhkan signing key pribadi.
- Jangan membagikan signing key atau kata sandinya.
- Build cloud memerlukan koneksi internet dan akun GitHub. Kuota/ketentuan GitHub Actions dapat berubah.
